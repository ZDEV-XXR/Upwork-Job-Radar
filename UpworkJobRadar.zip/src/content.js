// Upwork Radar — content script

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

  if (request.type === "CHECK_LOGIN_STATUS") {
    const isLoggedIn =
      document.querySelector('[data-qa="user-menu"]') !== null ||
      document.querySelector('.nav-item') !== null;
    sendResponse({ loggedIn: isLoggedIn });
    return false;
  }

  if (request.type === "FETCH_JOBS") {
    fetchJobs(request.keyword, request.freshMinutes || 15)
      .then(jobs => sendResponse(jobs))
      .catch(err => {
        console.error("[UpworkRadar] fetch error:", err.message);
        sendResponse([]);
      });
    return true;
  }

  if (request.type === "DEBUG_DUMP") {
    sendResponse(debugDump());
    return false;
  }
});

// ─── Main fetch — 4 layers ───────────────────────────────────────────────────

async function fetchJobs(keyword, freshMinutes) {
  const cutoff = Date.now() - freshMinutes * 60 * 1000;

  // ── Layer 1: Internal REST API ──────────────────────────────────────────────
  const apiUrl =
    "https://www.upwork.com/api/profiles/v2/search/jobs/url" +
    "?q=" + encodeURIComponent(keyword) + "&sort=recency&paging=0;10";
  try {
    const res = await fetch(apiUrl, {
      credentials: "include",
      headers: { "Accept": "application/json", "X-Requested-With": "XMLHttpRequest", "Referer": location.href }
    });
    if (res.ok) {
      const data = await res.json();
      const jobs = data?.searchResults?.jobs || data?.results || [];
      console.log("[UpworkRadar] Layer 1 API:", jobs.length, "jobs for:", keyword);
      if (jobs.length > 0)
        return filterMap(jobs, cutoff, j => j.publishedOn || j.createdOn || j.pubDate, j => j.ciphertext || j.id || j.jobUid, j => j.title);
    } else {
      console.warn("[UpworkRadar] Layer 1 status:", res.status);
    }
  } catch (e) { console.warn("[UpworkRadar] Layer 1 error:", e.message); }

  // ── Layer 2: Fetch search page HTML, parse __NEXT_DATA__ ───────────────────
  const pageUrl = "https://www.upwork.com/nx/search/jobs/?q=" + encodeURIComponent(keyword) + "&sort=recency";
  console.log("[UpworkRadar] Layer 2: fetching search page for:", keyword);
  try {
    const res = await fetch(pageUrl, { credentials: "include", headers: { "Accept": "text/html", "Referer": location.href } });
    if (res.ok) {
      const html = await res.text();
      const m = html.match(/<script id="__NEXT_DATA__" type="application\/json">([\s\S]*?)<\/script>/);
      if (m) {
        const d = JSON.parse(m[1]);
        const results =
          d?.props?.pageProps?.searchResults?.jobs?.results ||
          d?.props?.pageProps?.initialData?.jobs?.results ||
          d?.props?.pageProps?.results || [];
        console.log("[UpworkRadar] Layer 2 __NEXT_DATA__:", results.length, "results. pageProps keys:", Object.keys(d?.props?.pageProps || {}));
        if (results.length > 0)
          return filterMap(results, cutoff, j => j.publishedOn || j.createdOn || j.pubDate, j => j.ciphertext || j.id || j.jobUid, j => j.title);
      }
    } else { console.warn("[UpworkRadar] Layer 2 page status:", res.status); }
  } catch (e) { console.warn("[UpworkRadar] Layer 2 error:", e.message); }

  // ── Layer 3: Read __NEXT_DATA__ already in current page DOM ────────────────
  console.log("[UpworkRadar] Layer 3: current page __NEXT_DATA__");
  const nextEl = document.getElementById("__NEXT_DATA__");
  if (nextEl) {
    try {
      const d = JSON.parse(nextEl.textContent);
      const results =
        d?.props?.pageProps?.searchResults?.jobs?.results ||
        d?.props?.pageProps?.initialData?.jobs?.results ||
        d?.props?.pageProps?.results || [];
      const matched = results.filter(j =>
        (j.title + " " + (j.description || "")).toLowerCase().includes(keyword.toLowerCase())
      );
      console.log("[UpworkRadar] Layer 3 matched:", matched.length, "of", results.length, "results");
      if (matched.length > 0)
        return filterMap(matched, cutoff, j => j.publishedOn || j.createdOn || j.pubDate, j => j.ciphertext || j.id || j.jobUid, j => j.title);
    } catch (e) { console.warn("[UpworkRadar] Layer 3 error:", e.message); }
  }

  // ── Layer 4: DOM scrape visible job cards ──────────────────────────────────
  console.log("[UpworkRadar] Layer 4: DOM scrape for:", keyword);
  return domScrape(keyword, cutoff);
}

// ─── DOM scrape ──────────────────────────────────────────────────────────────

function domScrape(keyword, cutoff) {
  const jobs = [];

  const cardSelectors = [
    'article[data-test="job-tile"]',
    'article.job-tile',
    '[data-test="job-tile"]',
    'section.air3-card-section',
    '.job-tile'
  ];

  let cards = [];
  for (const sel of cardSelectors) {
    cards = Array.from(document.querySelectorAll(sel));
    if (cards.length > 0) {
      console.log("[UpworkRadar] DOM: found", cards.length, "cards with:", sel);
      break;
    }
  }

  if (cards.length === 0) {
    console.warn("[UpworkRadar] DOM: no job cards found on page:", location.href);
    return [];
  }

  for (const card of cards) {
    if (!card.innerText.toLowerCase().includes(keyword.toLowerCase())) continue;

    const timeSelectors = [
      '[data-test="job-published-date"]',
      '[data-test="posted-on"]',
      'small[data-test]', 'time', '.job-tile-header small'
    ];
    let timeText = "";
    for (const sel of timeSelectors) {
      const el = card.querySelector(sel);
      if (el) { timeText = el.innerText.toLowerCase(); break; }
    }

    const fresh = !timeText || timeText.includes("second") || timeText.includes("minute") ||
      timeText.includes("hour") || timeText.includes("1 day");
    if (!fresh) continue;

    const linkEl = card.querySelector("h3 a, h2 a, a[href*='/jobs/']");
    if (!linkEl) continue;

    const title = linkEl.innerText.trim();
    const href  = linkEl.getAttribute("href") || "";
    const match = href.match(/~[a-zA-Z0-9]+/);
    if (match && title) jobs.push({ id: match[0], title });
  }

  console.log("[UpworkRadar] DOM: found", jobs.length, "matching job(s) for:", keyword);
  return jobs;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function filterMap(jobs, cutoff, getDate, getId, getTitle) {
  return jobs
    .filter(j => { const d = getDate(j); return !d || new Date(d).getTime() >= cutoff; })
    .map(j => ({ id: getId(j), title: getTitle(j) }))
    .filter(j => j.id && j.title);
}

// ─── Debug dump (triggered from popup "Debug" button) ────────────────────────

function debugDump() {
  const out = { url: location.href, cardCounts: {}, nextDataKeys: null, resultsCount: 0, firstJob: null, timeElSamples: [] };

  const sels = ['article[data-test="job-tile"]','article.job-tile','[data-test="job-tile"]','section.air3-card-section','.job-tile'];
  sels.forEach(s => out.cardCounts[s] = document.querySelectorAll(s).length);

  const el = document.getElementById("__NEXT_DATA__");
  if (el) {
    try {
      const d = JSON.parse(el.textContent);
      out.nextDataKeys = Object.keys(d?.props?.pageProps || {});
      const arr = d?.props?.pageProps?.searchResults?.jobs?.results ||
        d?.props?.pageProps?.initialData?.jobs?.results ||
        d?.props?.pageProps?.results || [];
      out.resultsCount = arr.length;
      if (arr[0]) out.firstJob = { keys: Object.keys(arr[0]), title: arr[0].title, id: arr[0].ciphertext || arr[0].id, date: arr[0].publishedOn || arr[0].createdOn };
    } catch (e) { out.nextDataError = e.message; }
  }

  Array.from(document.querySelectorAll('article[data-test="job-tile"], [data-test="job-tile"]')).slice(0, 3)
    .forEach(c => {
      const t = c.querySelector('[data-test="job-published-date"],[data-test="posted-on"],time,small');
      out.timeElSamples.push(t ? t.outerHTML : "none");
    });

  console.log("[UpworkRadar DEBUG DUMP]", JSON.stringify(out, null, 2));
  return out;
}